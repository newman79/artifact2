var React = require('react');
var App = require('./components/App.jsx');

React.render(
    <App />,
    document.getElementById('example')
);
